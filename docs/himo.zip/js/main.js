
      $(document).ready(function(){
        
      $('.bike-slider').slick({
        arrows: false,
        dots: true,
        fade: true,
        autoplay: true,
        autoplaySpeed: 2000

    });
    // slider02
      $('.slider').slick({
        arrows: false,
        dots: true,
        fade: true,
        autoplay: true,
        autoplaySpeed: 2000

    });
  
          

    });